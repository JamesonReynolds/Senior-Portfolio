import java.util.Random;


public abstract class Algorithm < T extends Comparable < ? super T >> {

	public abstract void apply(T[] array); {
		
	}
	
    public long  time(T[] array) {
        long start, end;
          start = System.currentTimeMillis();
          
          this.apply(array);          // invoke the apply method
          
          end = System.currentTimeMillis();

          return  (end - start);        // returns elapsed time
    }
    
    public static Integer[] createRandomArray(int n) {
    	Integer [] randomArray = new Integer[n];
    	Random nRandom = new Random();
    			for(int i = 0; i < randomArray.length; i++) {
    				
    				int number = nRandom.nextInt();
    				randomArray[i] = number;
    			}
    				
    			return randomArray;
    			
    }
    
    
}

