
/**
 * 
 * @author Samuel Taylor and Jameson Reynolds
 * main method comparing the times for each of the three sorting algorithms: selection, insertion, and merging.
 *
 */
public abstract class TimeSorts extends SortingAlgorithm {

	public static void main(String[] args) {
		
		for(int i = 1; i < 5; i++) 
		{
			compareSorts((i*25000));
		}
	}

}
