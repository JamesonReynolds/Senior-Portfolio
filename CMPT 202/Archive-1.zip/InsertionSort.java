/**
 * 
 * @author Samuel Taylor and Jameson Reynolds
 *
 * @param <T> this will perform an insertion algorithm to put a random array of integers in ascending order.
 */
public class InsertionSort <T extends Comparable<? super T>> extends SortingAlgorithm <T> {

	@Override
	public void sort(T[] array) 
	{
		// TODO Auto-generated method stub
		for (int i=1; i < array.length; i++) 
		{
			    T key = array[i];
			    int j = i - 1;

			    while (j>=0 && array[j].compareTo(key) >0) 
			    {
			        array[j+1] = array[j];
			        j--;
			    }

			    array[j+1] = key;
		}
	}

}