/**
 * 
 * @author Samuel Taylor and Jameson Reynolds
 *
 * @param <T>
 */
public class SelectionSort < T extends Comparable <? super T>> extends SortingAlgorithm <T> 
{

	
	public void sort(T[] array) {
		selectionSort(array, array.length);
		
	}

	public static <T extends Comparable<? super T>> void selectionSort(T[] a, int n) 
	{
		for (int index = 0; index < n - 1; index++)
		{
			int indexOfNextSmallest = getIndexOfSmallest(a, index, n - 1);
			swap(a, index, indexOfNextSmallest);
		} 
	} 

	/** Task: Finds the index of the smallest value in a portion of an 
	 *        array.
	 *  @param a      an array of Comparable objects
	 *  @param first  an integer >= 0 and < a.length that is the index of 
	 *                the first array element to consider
	 *  @param last   an integer >= first and < a.length that is the index 
	 *                of the last array element to consider
	 *  @return the index of the smallest value among
	 *          a[first], a[first + 1], . . . , a[last] */
	
	private static <T extends Comparable<? super T>> int getIndexOfSmallest(T[] a, int first, int last) {
		
		T min = a[first];
		int indexOfMin = first;
		
		for (int index = first + 1; index <= last; index++) {
			
			if (a[index].compareTo(min) < 0) {
				min = a[index];
				indexOfMin = index;
			} 
		} 
		
		return indexOfMin;
	} 

	/** Task: Swaps the array elements a[i] and a[j].
	 *  @param a  an array of objects
	 *  @param i  an integer >= 0 and < a.length
	 *  @param j  an integer >= 0 and < a.length */
	

	public static void main(String[] args) {
		
		String[] array = {"hello", "world", "alpha", "cmpt", "sorting"};
		System.out.println(" original array: ");
		
		for (int i=0; i<array.length; i++) 
			
			System.out.print (array[i] + " ");
		System.out.println();

		selectionSort(array, array.length);
		System.out.println(" sorted array: ");
		
		for (int i=0; i<array.length; i++) 
			
			System.out.print (array[i] + " ");
		System.out.println();
	} 

} 											// end of the SortArray