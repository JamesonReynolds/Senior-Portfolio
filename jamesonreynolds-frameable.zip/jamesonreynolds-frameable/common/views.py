from django.views.generic import TemplateView


class AboutView (TemplateView):
    template_name = 'common/about_us.html'


class ContactView (TemplateView):
    template_name = 'common/contact_us.html'


class GalleryView (TemplateView):
    template_name = 'common/gallery.html'
