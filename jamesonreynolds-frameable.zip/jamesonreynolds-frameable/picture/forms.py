from django import forms


class PictureForm(forms.Form):
    file = forms.ImageField(label='Upload a Picture')
