from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views.generic import View

from picture.models import Picture
from picture.forms import PictureForm


class UploadView(View):
    def get(self, request, *args, **kwargs):
        form = PictureForm()
        context = {'form': form}
        return render_to_response(
            'picture/upload.html', context=context,
            context_instance=RequestContext(request),
        )

    def post(self, request, *args, **kwargs):
        form = PictureForm(request.POST, request.FILES)
        if form.is_valid():
            newpic = Picture(file=request.FILES['file'])
            newpic.save()
            context = {'form': form, 'picture': newpic}
            return render_to_response(
                'picture/upload.html', context=context,
                context_instance=RequestContext(request),
            )
        else:
            context = {'form': form}
            return render_to_response(
                'picture/upload.html', context=context,
                context_instance=RequestContext(request),
            )


class RemoveView(View):
    def get(self, request, *args, **kwargs):
        picture = Picture.objects.get(pk=kwargs['pk'])
        storage, path = picture.file.storage, picture.file.path
        storage.delete(path)
        picture.delete()
        return HttpResponseRedirect(reverse('picture:upload'))
