from django.db import models

from order.models import Order


class Picture(models.Model):
    file = models.ImageField(upload_to='picture/%Y/%m/%d')
    order = models.OneToOneField(Order, on_delete=models.CASCADE, blank=True, null=True,)
