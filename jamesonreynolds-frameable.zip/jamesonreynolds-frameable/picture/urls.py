from django.conf.urls import url

from picture.views import UploadView, RemoveView

urlpatterns = [
    url(r'^upload/$', UploadView.as_view(), name='upload'),
    url(r'^(?P<pk>[0-9]+)/remove/$', RemoveView.as_view(), name='remove'),
]
