from django.conf.urls import url

from frame.views import FrameListView, FrameSelectView

urlpatterns = [
    url(r'^(?P<picture_pk>[0-9]+)/list/$', FrameSelectView.as_view(), name='select'),
    url(r'^list/$', FrameListView.as_view(), name='preview'),
]
