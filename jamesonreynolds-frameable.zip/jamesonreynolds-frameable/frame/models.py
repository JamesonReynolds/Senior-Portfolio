from django.db import models

from . import constants
from order.models import Order


class Frame(models.Model):
    image = models.ImageField(upload_to='frame/%Y/%m/%d')
    price = models.DecimalField(decimal_places=2, max_digits=5)
    description = models.CharField(max_length=255)
    width = models.DecimalField(decimal_places=2, max_digits=5)
    length = models.DecimalField(decimal_places=2, max_digits=5)
    color = models.CharField(max_length=20, choices=constants.FRAME_COLOR_CHOICES)
    order = models.ManyToManyField(Order, blank=True)

    def __str__(self):
        return '{} {}x{} {} ${}'.format(
            self.description, self.length, self.width, self.color.title(), self.price)
