from django import template

register = template.Library()


@register.filter
def string_to_int(value):
    """ Change string to int """
    return int(value)
