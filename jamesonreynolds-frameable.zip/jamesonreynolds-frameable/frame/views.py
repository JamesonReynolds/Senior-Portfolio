from django.core.urlresolvers import reverse
from django.shortcuts import render_to_response, redirect
from django.template import RequestContext
from django.views.generic import View
from django.views.generic.list import ListView

from .models import Frame
from .forms import FrameSelectForm
from order.models import Order
from picture.models import Picture


class FrameListView(ListView):
    model = Frame
    template_name = 'frame/preview_frame.html'


class FrameSelectView(View):
    template_name = 'frame/select_frame.html'

    def get(self, request, *args, **kwargs):
        form = FrameSelectForm()
        context = {
            'form': form,
            'picture': Picture.objects.get(pk=kwargs['picture_pk']),
            'frames': Frame.objects.all(),
        }
        return render_to_response(
            self.template_name, context=context,
            context_instance=RequestContext(request),
        )

    def post(self, request, *args, **kwargs):
        form = FrameSelectForm(request.POST)
        if form.is_valid():
            picture = Picture.objects.get(pk=kwargs['picture_pk'])
            frames = Frame.objects.filter(pk__in=request.POST.getlist('frames'))
            price = 0
            for frame in frames:
                price += frame.price
            if request.user.pk:
                order = Order.objects.create(price=price, user=request.user)
            else:
                order = Order.objects.create(price=price)
            picture.order = order
            picture.save()
            for frame in frames:
                frame.order.add(order)
            return redirect(
                reverse('order:checkout', kwargs={'order_pk': order.pk})
            )
        else:
            context = {'form': form}
            return render_to_response(
                'frame/select_frame.html', context=context,
                context_instance=RequestContext(request),
            )
