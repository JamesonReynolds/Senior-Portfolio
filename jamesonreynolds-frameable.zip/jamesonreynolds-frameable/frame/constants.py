BLACK = 'black'
BROWN = 'brown'
FRAME_COLOR_CHOICES = (
    (BLACK, 'Black'),
    (BROWN, 'Brown'),
)
