from django import forms
from django.forms.widgets import CheckboxSelectMultiple

from .models import Frame


class FrameSelectForm(forms.Form):
    frames = forms.ModelMultipleChoiceField(
        queryset=Frame.objects.all(), widget=CheckboxSelectMultiple(),
    )
