from django.contrib import admin

from .models import Frame

admin.site.register(Frame)
