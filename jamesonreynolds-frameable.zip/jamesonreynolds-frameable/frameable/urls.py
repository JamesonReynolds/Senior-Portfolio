from django.conf import settings
from django.conf.urls import include, url
from django.contrib import admin
from django.views.static import serve

from accounts.views import IndexView
from common.views import AboutView, ContactView, GalleryView

urlpatterns = [
    url(r'^$', IndexView.as_view(), name='index'),
    url(r'^about/', AboutView.as_view(), name='about'),
    url(r'^contact/', ContactView.as_view(), name='contact'),
    url(r'^gallery/', GalleryView.as_view(), name='gallery'),
    url(r'^frame/', include('frame.urls', namespace='frame')),
    url(r'^order/', include('order.urls', namespace='order')),
    url(r'^picture/', include('picture.urls', namespace='picture')),
    url('', include('django.contrib.auth.urls', namespace='auth')),
    url('', include('social.apps.django_app.urls', namespace='social')),
    url(r'^admin/', admin.site.urls),
    url(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}),
]

