from frameable.settings.base import *

import os

ALLOWED_HOSTS = ['frameable.org', 'www.frameable.org']

STATIC_ROOT = os.path.expanduser('~/staticfiles')
MEDIA_ROOT = os.path.expanduser('~/media')

if not os.path.isdir(STATIC_ROOT):
    os.makedirs(STATIC_ROOT)

if not os.path.isdir(MEDIA_ROOT):
    os.makedirs(MEDIA_ROOT)

DEBUG = False

SOCIAL_AUTH_FACEBOOK_KEY = '1113077738726297'
SOCIAL_AUTH_FACEBOOK_SECRET = 'c67cca6944e202f32ee9870b9d96617b'
