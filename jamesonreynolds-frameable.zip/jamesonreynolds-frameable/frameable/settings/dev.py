from frameable.settings.base import *

DEBUG = True
TEMPLATES[0]['OPTIONS']['debug'] = DEBUG

# Removes password validation/complexity
# AUTH_PASSWORD_VALIDATORS = []

SOCIAL_AUTH_FACEBOOK_KEY = '1113374808696590'
SOCIAL_AUTH_FACEBOOK_SECRET = '0227d7cb612c90aa5cebb1c4d142cd6f'

try:
    from frameable.settings.dev_local import *
except ImportError:
    pass
