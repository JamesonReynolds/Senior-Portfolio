#!/usr/bin/env bash

usage="Usage: $0 <package> <host>"

if [ "x$1" == "x" ]; then
    echo "Requires a deployment package file as an argument."
    echo $usage
    exit 1
fi

package_file=$1
base_package_file=`basename $package_file`
package_name=`basename $package_file .tar.gz`

shift

for host in $@; do
    echo "Deploy $package_name to $host"
    scp $package_file frameable@$host:`basename $base_package_file`

ssh -o StrictHostKeyChecking=no frameable@$host "bash -xe" << EOF
[ -d "$package_name" ] || virtualenv "$package_name" -p /usr/bin/python3
$package_name/bin/pip install $base_package_file --upgrade
$package_name/bin/pip install uwsgi
$package_name/bin/frameable-manage collectstatic --noinput

[ ! -s vframeable ] || unlink vframeable
ln -s $package_name vframeable
mkdir -p logs

supervisorctl restart frameable || true

EOF

done
