from django.db import models
from django.contrib.auth.models import User

from common.models import Address


class Order(models.Model):
    address = models.ForeignKey(Address, null=True, blank=True)
    price = models.DecimalField(decimal_places=2, max_digits=5)
    description = models.CharField(max_length=200)
    email = models.CharField(max_length=200, blank=True, null=True)
    phone_number = models.CharField(max_length=20)
    paid = models.BooleanField(default=False)
    fulfilled = models.BooleanField(default=False)
    user = models.ForeignKey(User, null=True, blank=True)

    def __str__(self):
        return "{}, {}, {}, Paid: {}".format(
            self.email, self.phone_number, self.price, self.paid)
