from django import forms

from common.constants import STATE_CHOICES


class CheckoutForm(forms.Form):
    name = forms.CharField(max_length=50)
    street = forms.CharField(max_length=100)
    city = forms.CharField(max_length=50)
    state = forms.ChoiceField(choices=STATE_CHOICES)
    postal_code = forms.CharField(max_length=12, label="Zip")
    email = forms.CharField(max_length=200)
    phone_number = forms.CharField(max_length=20, label="Phone")
