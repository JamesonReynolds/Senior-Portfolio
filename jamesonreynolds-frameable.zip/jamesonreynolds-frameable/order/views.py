from django.conf import settings
from django.core.urlresolvers import reverse
from django.shortcuts import render_to_response, redirect
from django.template import RequestContext
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View

import stripe

from common.models import Address
from order.models import Order

from order.forms import CheckoutForm


class CheckoutView(View):
    def get(self, request, *args, **kwargs):
        form = CheckoutForm()
        order = Order.objects.get(pk=kwargs['order_pk'])
        context = {
            'form': form,
            'order': order,
        }
        return render_to_response(
            'order/checkout.html', context=context,
            context_instance=RequestContext(request),
        )

    def post(self, request, *args, **kwargs):
        form = CheckoutForm(request.POST)
        order = Order.objects.get(pk=kwargs['order_pk'])
        if form.is_valid():
            post = request.POST
            address = Address.objects.create(
                name=post['name'], street=post['street'], city=post['city'],
                state=post['state'], postal_code=post['postal_code']
            )
            order.address = address
            order.email = post['email']
            order.phone_number = post['phone_number']
            order.save()
            return redirect(
                reverse('order:payment', kwargs={'order_pk': order.pk})
            )
        else:
            context = {
                'form': form,
                'order': order,
            }
            return render_to_response(
                'order/checkout.html', context=context,
                context_instance=RequestContext(request),
            )


class PaymentView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(PaymentView, self).dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        order = Order.objects.get(pk=kwargs['order_pk'])
        picture = order.picture
        frames = order.frame_set.all()
        price = str(int(order.price * 100))
        frame_number = len(order.frame_set.all())
        description = "{} Frames".format(frame_number)
        order.description = description
        order.save()
        context = {
            'stripe_key': settings.STRIPE_PUBLIC_KEY,
            'price': price,
            'order_pk': order.pk,
            'description': description,
            'email': order.email,
            'picture': picture,
            'frames': frames,
        }
        return render_to_response(
            'order/payment.html', context=context,
            context_instance=RequestContext(request),
        )

    def post(self, request, *args, **kwargs):
        order = Order.objects.get(pk=kwargs['order_pk'])
        stripe.api_key = settings.STRIPE_SECRET_KEY
        token = request.POST.get('stripeToken')
        try:
            charge = stripe.Charge.create(
                amount=int(order.price * 100),
                currency="usd",
                source=token,
                description=order.description
            )
        except stripe.error.CardError as e:
            return redirect(reverse('index'))
        order.paid = True
        order.save()
        return redirect(reverse('index'))
