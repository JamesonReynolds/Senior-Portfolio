from django.conf.urls import url

from .views import PaymentView, CheckoutView

urlpatterns = [
    url(r'^(?P<order_pk>[0-9]+)/checkout/$', CheckoutView.as_view(), name='checkout'),
    url(r'^(?P<order_pk>[0-9]+)/payment/$', PaymentView.as_view(), name='payment'),
]
